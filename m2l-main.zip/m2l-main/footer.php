    </div>
    <div class="footer">
        <ul>
            <li class="ligne left"><a>©2020-2021 MyLimayrac.fr tous droits réservés.</a></li>
            <!--Quand on arrive sur le site, seulement formulaire de contact visible-->
            <li class="ligne right"><a class="<?php if($active==5){echo"active";}?>" href="/m2l/contact.php">CONTACT</a></li>
        </ul>
</body>
</html>